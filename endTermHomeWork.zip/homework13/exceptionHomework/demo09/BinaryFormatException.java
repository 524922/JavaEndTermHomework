package endTermHomeWork.homework13.exceptionHomework.demo09;

public class BinaryFormatException extends NumberFormatException{
    public BinaryFormatException(String s){
        super(s);
    }
}
