package endTermHomeWork.homework7.problem.problem10;

public class QuadraticEquation {
}
