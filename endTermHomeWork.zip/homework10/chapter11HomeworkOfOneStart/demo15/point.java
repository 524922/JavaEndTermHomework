package endTermHomeWork.homework10.chapter11HomeworkOfOneStart.demo15;

public class point {
    public float x;
    public float y;
    point(){
        this.x=0;
        this.y=0;
    }
}
