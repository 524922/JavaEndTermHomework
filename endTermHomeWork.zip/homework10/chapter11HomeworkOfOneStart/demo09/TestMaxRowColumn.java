package endTermHomeWork.homework10.chapter11HomeworkOfOneStart.demo09;

public class TestMaxRowColumn {
    public static void main(String[] args) {
        MaxRowColumn maxRowColumn = new MaxRowColumn();
        maxRowColumn.init();
        maxRowColumn.findMaxRow();
        maxRowColumn.findMaxCol();
        maxRowColumn.putout();
    }
}
