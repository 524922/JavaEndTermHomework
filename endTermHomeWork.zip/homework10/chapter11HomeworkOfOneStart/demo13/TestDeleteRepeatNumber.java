package endTermHomeWork.homework10.chapter11HomeworkOfOneStart.demo13;

public class TestDeleteRepeatNumber {
    public static void main(String[] args) {
        DeleteRepeatNumber deleteRepeatNumber = new DeleteRepeatNumber();
        deleteRepeatNumber.createList();
        System.out.println("=======");
        deleteRepeatNumber.deleteRepeatNum();
    }
}
