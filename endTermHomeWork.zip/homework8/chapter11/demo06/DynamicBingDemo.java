package endTermHomeWork.homework8.chapter11.demo06;

import classAndObject.demo01.Student;

public class DynamicBingDemo {
    public static void main(String[] args) {
//        m(new )
    }
    public static void m(Object x){
        System.out.println(x.toString());
    }
}

class GraduateStudent extends Student{

}
//class Student extends Person{
//    @Override
//    public String toString(){
//        return "Student";
//    }
//    class Person extends Object{
//
//    }
//}
