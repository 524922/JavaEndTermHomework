package endTermHomeWork.hoework2;

public class homework2 {
    public static void main(String[] args) {
//	    //1-1
//		System.out.println("Welcome to Java");
//		//1-2
//		System.out.println("Programing is fun!");
//		System.out.println("Fundamental First");
//		System.out.println("Problem Driven");
//		//1-3
//		System.out.print("(10.5+2*3)/(45-3.5)=");
//		System.out.println((10.5+2*3)/(45-3.5));
//		//1-4
//		System.out.println("Welcome to Java");
//		//1-5
////		System.out.println(1/0);
//		//1-6
//		System.out.print("Celsius 35 is Fahrenheit degree ");
//		System.out.println((9/5)*35+32);
//
//		//2-1
//		double radius;
//		double areas;
//		radius=20;
//		areas=radius*radius*3.14159;
//		System.out.println("result:"+areas);
//
        //2-2
//		Scanner input=new Scanner(System.in);
//		double radius=input.nextDouble();
//		double area=radius*radius*3.1459;
//        System.out.println(area);
//		input.close();

        //2-3
//        Scanner input=new Scanner(System.in);
//        System.out.print("please enter three numbers:");
//        double number1=input.nextDouble();
//        double number2=input.nextDouble();
//        double number3=input.nextDouble();
//        double average=(number1+number2+number3)/3;
//        System.out.println("the average is:"+average);

        //2-4
//        final double PI=3.14159;
//        Scanner input=new Scanner(System.in);
//        System.out.print("enter number for radius:");
//        double radius=input.nextDouble();
//        double area=radius*radius*PI;
//        System.out.println("the area is:"+area);

        //2-5
//        Scanner input=new Scanner(System.in);
//        System.out.print("enter an integer for seconds:");
//        int seconds=input.nextInt();
//        int minutes=seconds/60;
//        int remainSeconds=seconds%60;
//        System.out.println("second:"+seconds+"is "+minutes+"minutes: "+"and "+remainSeconds+"seconds");

        //2-6
//        Scanner input=new Scanner(System.in);
//        System.out.println("please enter:");
//        double fahrenheit=input.nextDouble();
//        double celsius=(5.0/9)*(fahrenheit-32);
//        System.out.println("result:"+celsius);

        //2-7
//        long totalMilliseconds=System.currentTimeMillis();
//        long totalSeconds=totalMilliseconds/1000;
//        long currentSecond=totalSeconds%60;
//        long totalMinutes=totalSeconds/60;
//        long currentMinutes=totalMinutes%60;
//        long totalHours=totalMinutes/60;
//        long currentHOurs=totalHours%24;
//        System.out.println("current time:"+currentHOurs+":"+currentMinutes+":"+currentSecond);

        //2-8
//        Scanner input =new Scanner(System.in);
//        System.out.println("please enter purchase amount");
//        double purchaseAmount=input.nextDouble();
//        double tax=purchaseAmount*0.06;
//        System.out.println("sales tax is: $"+(int)(tax*100)/100.0);

        //2-9
//        Scanner input=new Scanner(System.in);
//        System.out.println("please enter��");
//        double annualInterestRate=input.nextDouble();
//        double monthlyInterestRate=annualInterestRate/1200;
//        System.out.println("enter again:");
//        int numberOfYears=input.nextInt();
//        System.out.println("enter:");
//        double loanAmount=input.nextDouble();
//        double monthlyPayment=loanAmount*monthlyInterestRate/(1
//                -1/Math.pow(1+monthlyInterestRate,numberOfYears*12));
//        double totalPayment=monthlyPayment*numberOfYears*12;
//        System.out.println("month:"+(int)(monthlyInterestRate*100)/100.0);
//        System.out.println("total:"+(int)(totalPayment*100)/100.0);

        //2-10
//        Scanner input=new Scanner(System.in);
//        System.out.println("enter:");
//        double amount=input.nextDouble();
//        int remainAmount=(int)(amount*100);
//        System.out.println("enter:");


    }
}
